import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import mysql from 'mysql2/promise';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'Pirtle4life',
  database: process.env.DB_NAME || 'truetrace',
  port: Number(process.env.DB_PORT || 3306),
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Health check
app.get('/api/health', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT 1 as ok');
    res.json({ status: 'ok', db: rows[0].ok === 1 ? 'connected' : 'unknown' });
  } catch (e) {
    res.status(500).json({ status: 'error', message: e.message });
  }
});

// Products
app.get('/api/Products', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM Products ORDER BY ProductID DESC');
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/Products', async (req, res) => {
  const { sku, name, price } = req.body;
  if (!sku || !name) return res.status(400).json({ error: 'sku and name are required' });
  try {
    const [result] = await pool.query('INSERT INTO Products (SKU, ProductName, UnitPrice) VALUES (?, ?, ?)', [SKU, ProductName, UnitPrice || 0]);
    res.status(201).json({ id: result.ProductID, SKU, ProductName, UnitPrice: UnitPricerice || 0 });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Inventory
app.get('/api/Inventory', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT p.ProductID, p.SKU, p.ProductName, p.Category, p.UnitPrice, i.QuantityOnHand
      FROM Products p
      LEFT JOIN Inventory i ON i.ProductID = p.ProductID
      ORDER BY p.ProductID DESC
    `);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Set/Upsert inventory for a product/location
app.post('/api/Inventory', async (req, res) => {
  const { ProductID, QuantityOnHand } = req.body;
  if (!ProductID) return res.status(400).json({ error: 'product_id is required' });
  try {
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      await conn.query(`
        INSERT INTO Inventory (ProductID, QuantityOnHand)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE QuantityOnHand = VALUES(QuantityOnHand)
      `, [ProductID, QuantityOnHand]);
      await conn.commit();
      res.status(200).json({ ok: true });
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Simple homepage
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => {
  console.log(`Server listening on http://localhost:${port}`);
});