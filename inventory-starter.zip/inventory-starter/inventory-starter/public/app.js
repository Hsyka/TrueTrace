async function fetchJSON(url, opts) {
  const res = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...opts });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

async function loadInventory() {
  const data = await fetchJSON('/api/inventory');
  const tbody = document.querySelector('#prodTable tbody');
  tbody.innerHTML = '';
  data.forEach(row => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${row.ProductID ?? ''}</td>
      <td>${row.SKU ?? ''}</td>
      <td>${row.ProductName ?? ''}</td>
      <td>${row.Category ?? ''}</td>
      <td>${row.UnitPrice ?? ''}</td>
      <td>${row.QuantityOnHand ?? ''}</td>
    `;
    tbody.appendChild(tr);
  });
}

document.querySelector('#refreshBtn').addEventListener('click', loadInventory);

document.querySelector('#productForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const body = {
    SKU: form.SKU.value.trim(),
    ProductName: form.ProductName.value.trim(),
    UnitPrice: parseFloat(form.UnitPrice.value || '0')
  };
  try {
    await fetchJSON('/api/products', { method: 'POST', body: JSON.stringify(body) });
    form.reset();
    await loadInventory();
  } catch (err) {
    alert('Error: ' + err.message);
  }
});

document.querySelector('#invForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const body = {
    ProductID: Number(form.ProductID.value),
    QuantityOnHand: Number(form.QuantityOnHand.value)
  };
  try {
    await fetchJSON('/api/Inventory', { method: 'POST', body: JSON.stringify(body) });
    form.reset();
    await loadInventory();
  } catch (err) {
    alert('Error: ' + err.message);
  }
});

// initial load
loadInventory().catch(console.error);